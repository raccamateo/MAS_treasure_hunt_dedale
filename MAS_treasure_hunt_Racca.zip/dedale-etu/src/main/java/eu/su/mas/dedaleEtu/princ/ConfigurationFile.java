package eu.su.mas.dedaleEtu.princ;

import eu.su.mas.dedale.env.EnvironmentType;
import eu.su.mas.dedale.env.GeneratorType;

/**
 * Configuration file for a Dedale instance
 * It contains parameters for both the network/platform and the environment.
 *
 * Author: hc
 */
public final class ConfigurationFile {

	/************************************
	 * Network and platform parameters
	 ************************************/

	// Specifies if the platform is distributed or not, and if the current computer is the main one.
	public static boolean PLATFORMisDISTRIBUTED = false;
	public static boolean COMPUTERisMAIN = true;

	// Network configuration
	public static String PLATFORM_HOSTNAME = "127.0.0.1";
	public static String PLATFORM_ID = "Ithaq";
	public static Integer PLATFORM_PORT = 8887;

	// List of containers to be created on the current computer
	public static String LOCAL_CONTAINER_NAME = PLATFORM_ID + "_" + "container1";
	public static String LOCAL_CONTAINER2_NAME = PLATFORM_ID + "_" + "container2";
	public static String LOCAL_CONTAINER3_NAME = PLATFORM_ID + "_" + "container3";
	public static String LOCAL_CONTAINER4_NAME = PLATFORM_ID + "_" + "container4";

	/************************************
	 * Environment parameters
	 ************************************/

	/**
	 * The type of environment (GraphStream or JME).
	 */
	public static EnvironmentType ENVIRONMENT_TYPE = EnvironmentType.GS;

	/**
	 * The environment generation method (manual or specific generator).
	 */
	public static GeneratorType GENERATOR_TYPE = GeneratorType.MANUAL;

	/**
	 * The name of the GateKeeper agent responsible for managing the platform.
	 */
	public static String DEFAULT_GATEKEEPER_NAME = "GK";

	/************************************
	 * Environment parameters when the environment is loaded.
	 ************************************/

	// Topology file, leave it null if the environment is generated or already online.
	public static String INSTANCE_TOPOLOGY = "resources/URV.dgs";

	// Configuration of elements on the map, leave it null if not needed.
	public static String INSTANCE_CONFIGURATION_ELEMENTS = "resources/URVelements.txt";

	/************************************
	 * Environment parameters when it is generated.
	 ************************************/

	// Size of the generated environment (mandatory).
	public static Integer ENVIRONMENT_SIZE = 4;

	// Parameters required for some generators (used by the BARABASI_ALBERT generator).
	public static Integer OPTIONAL_ADDITIONAL_ENVGENERATOR_PARAM1 = 1;
	public static Integer[] GENERATOR_PARAMETERS = { ENVIRONMENT_SIZE, OPTIONAL_ADDITIONAL_ENVGENERATOR_PARAM1 };

	// Wumpus proximity detection radius
	public static final Integer DEFAULT_DETECTION_RADIUS = 0;

	// Agents communication radius
	public static Integer DEFAULT_COMMUNICATION_REACH = 300;

	// Elements on the map (well, gold, diamonds)
	public static boolean ACTIVE_WELL = false;
	public static boolean ACTIVE_GOLD = true;
	public static boolean ACTIVE_DIAMOND = true;

	/************************************
	 * Agents characteristics
	 ************************************/

	// Configuration file for agents (defines their capabilities).
	public static String INSTANCE_CONFIGURATION_ENTITIES = "resources/treasureHunt/agents.json";
}

