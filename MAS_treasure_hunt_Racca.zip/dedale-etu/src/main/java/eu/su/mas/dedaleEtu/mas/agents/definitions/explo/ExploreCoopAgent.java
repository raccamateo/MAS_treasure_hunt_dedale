package eu.su.mas.dedaleEtu.mas.agents.definitions.explo;

import java.util.ArrayList;
import java.util.List;

import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import eu.su.mas.dedale.mas.agent.behaviours.platformManagment.*;

import eu.su.mas.dedaleEtu.mas.behaviours.ExploCoopBehaviour;
import eu.su.mas.dedaleEtu.mas.knowledge.MapRepresentation;

import jade.core.behaviours.Behaviour;

/**
 * This class defines a cooperative exploration agent extending the capabilities of AbstractDedaleAgent.
 * It is designed to explore the environment in cooperation with other agents by sharing map information and coordinating movements.
 */
public class ExploreCoopAgent extends AbstractDedaleAgent {

	private static final long serialVersionUID = -7969469610241668140L;

	// The agent's internal representation of the map
	private MapRepresentation myMap;

	/**
	 * Setup method to initialize the agent. This method is called when the agent is started.
	 */
	protected void setup() {
		super.setup(); // Call the setup method of the base class (AbstractDedaleAgent)

		// Retrieve the arguments provided to the agent upon creation
		final Object[] args = getArguments();

		// List to store the names of other agents to cooperate with
		List<String> list_agentNames = new ArrayList<String>();

		// Check if the agent was started with the expected arguments
		if (args.length == 0) {
			System.err.println("Error while creating the agent, names of agents to contact expected");
			System.exit(-1); // Exit if no arguments were provided
		} else {
			// Start iterating from index 2 due to a specific requirement (to be fixed in future releases)
			int i = 2;
			while (i < args.length) {
				// Add the names of agents to cooperate with to the list
				list_agentNames.add((String) args[i]);
				i++;
			}
		}

		// List to hold behaviours that this agent will execute
		List<Behaviour> lb = new ArrayList<Behaviour>();

		// Add the cooperative exploration behaviour with the list of agents to cooperate with
		lb.add(new ExploCoopBehaviour(this, this.myMap, list_agentNames));

		// Add a behaviour to start the defined behaviours
		addBehaviour(new startMyBehaviours(this, lb));

		System.out.println("The agent " + this.getLocalName() + " is started");
	}
}
