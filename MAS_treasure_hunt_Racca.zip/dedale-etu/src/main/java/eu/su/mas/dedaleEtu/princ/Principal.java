package eu.su.mas.dedaleEtu.princ;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import eu.su.mas.dedaleEtu.mas.agents.definitions.CollectorAgent;
import eu.su.mas.dedaleEtu.mas.agents.definitions.explo.ExploreCoopAgent;
import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import eu.su.mas.dedale.mas.agents.GateKeeperAgent;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

import org.junit.Assert;
import jade.wrapper.AgentContainer;

/**
 * This class is responsible for starting the platform and the agents.
 * To launch your agents in the desired environment, you need to:
 * <ul>
 * <li> Set the ConfigurationFile parameters (and potentially update the files in resources/) {@link ConfigurationFile}</li>
 * <li> Create your agent classes and add them to the createAgents method below </li>
 * </ul>
 * @author hc
 *
 */
public class Principal {

	private static HashMap<String, ContainerController> containerList = new HashMap<String, ContainerController>();
	private static List<AgentController> agentList;
	private static Runtime rt;

	public static void main(String[] args) {

		if (ConfigurationFile.COMPUTERisMAIN) {
			// If this computer is the main platform, create the platform and agents
			rt = createPlatform(containerList);
			agentList = createAgents(containerList);
			startAgents(agentList);
		} else {
			// If this computer is not the main platform, connect to it and create agents
			containerList.putAll(connectToPlatform(ConfigurationFile.LOCAL_CONTAINER_NAME,
					ConfigurationFile.PLATFORM_HOSTNAME, ConfigurationFile.PLATFORM_ID, ConfigurationFile.PLATFORM_PORT));
			agentList = createAgents(containerList);
			startAgents(agentList);
		}
	}

	/**
	 * Create an empty platform composed of 1 main container and 3 containers.
	 * @param containerList
	 * @return a reference to the platform and update the containerList
	 */
	private static Runtime createPlatform(HashMap<String, ContainerController> containerList) {

		Runtime rt = Runtime.instance();

		// 1) Create a platform (main container + DF + AMS)
		Profile mainProfile = new ProfileImpl(ConfigurationFile.PLATFORM_HOSTNAME, ConfigurationFile.PLATFORM_PORT,
				ConfigurationFile.PLATFORM_ID);
		System.out.println("Creating a main container..." + mainProfile);
		AgentContainer mainContainerRef = rt.createMainContainer(mainProfile); // DF and AMS are included

		// 2) Create the containers
		containerList.putAll(createContainers(rt));

		// 3) Create monitoring agents: RMA agent (used to debug and monitor the platform) and Sniffer agent (to monitor communications)
		createMonitoringAgents(mainContainerRef);

		System.out.println("Platform initialized.");
		return rt;
	}

	/**
	 * Create the containers used to hold the agents.
	 * @param rt The reference to the main container
	 * @return a HashMap associating the name of a container and its object reference.
	 */
	private static HashMap<String, ContainerController> createContainers(Runtime rt) {
		String containerName;
		ProfileImpl containerProfile;
		ContainerController containerRef;
		HashMap<String, ContainerController> containerList = new HashMap<String, ContainerController>();

		System.out.println("Creating containers ...");

		// Create local container 1
		containerName = ConfigurationFile.LOCAL_CONTAINER_NAME;
		containerProfile = new ProfileImpl(ConfigurationFile.PLATFORM_HOSTNAME, ConfigurationFile.PLATFORM_PORT,
				ConfigurationFile.PLATFORM_ID);
		containerProfile.setParameter(Profile.CONTAINER_NAME, containerName);
		System.out.println("Creating container " + containerProfile);
		containerRef = rt.createAgentContainer(containerProfile);
		containerList.put(containerName, containerRef);

		// Create local container 2
		containerName = ConfigurationFile.LOCAL_CONTAINER2_NAME;
		containerProfile = new ProfileImpl(ConfigurationFile.PLATFORM_HOSTNAME, ConfigurationFile.PLATFORM_PORT,
				ConfigurationFile.PLATFORM_ID);
		containerProfile.setParameter(Profile.CONTAINER_NAME, containerName);
		System.out.println("Creating container " + containerProfile);
		containerRef = rt.createAgentContainer(containerProfile);
		containerList.put(containerName, containerRef);

		// Create local container 3
		containerName = ConfigurationFile.LOCAL_CONTAINER3_NAME;
		containerProfile = new ProfileImpl(ConfigurationFile.PLATFORM_HOSTNAME, ConfigurationFile.PLATFORM_PORT,
				ConfigurationFile.PLATFORM_ID);
		containerProfile.setParameter(Profile.CONTAINER_NAME, containerName);
		System.out.println("Creating container " + containerProfile);
		containerRef = rt.createAgentContainer(containerProfile);
		containerList.put(containerName, containerRef);

		// Create local container 4
		containerName = ConfigurationFile.LOCAL_CONTAINER4_NAME;
		containerProfile = new ProfileImpl(ConfigurationFile.PLATFORM_HOSTNAME, ConfigurationFile.PLATFORM_PORT,
				ConfigurationFile.PLATFORM_ID);
		containerProfile.setParameter(Profile.CONTAINER_NAME, containerName);
		System.out.println("Creating container " + containerProfile);
		containerRef = rt.createAgentContainer(containerProfile);
		containerList.put(containerName, containerRef);

		System.out.println("Creating containers done");
		return containerList;
	}

	/**
	 * Create and connect a container to the main platform.
	 * @param containerName Name of the container
	 * @param host IP of the host where the main-container should listen to
	 * @param platformID Symbolic name of the platform
	 * @param port Port number (default: 8888)
	 * @return a HashMap with the container name and its object reference
	 */
	private static HashMap<String, ContainerController> connectToPlatform(String containerName, String host,
																		  String platformID, Integer port) {

		ProfileImpl containerProfile;
		ContainerController containerRef;
		HashMap<String, ContainerController> containerList = new HashMap<String, ContainerController>();
		Runtime runtime = Runtime.instance();

		if (port == null) {
			port = ConfigurationFile.PLATFORM_PORT;
		}

		System.out.println(
				"Creating and connecting container " + containerName + " to the host: " + host + ", platform ID: "
						+ platformID + " on port " + port);

		containerProfile = new ProfileImpl(host, port, platformID);
		containerProfile.setParameter(Profile.CONTAINER_NAME, containerName);
		containerRef = runtime.createAgentContainer(containerProfile);

		containerList.put(containerName, containerRef);
		return containerList;
	}

	/**
	 * Create the monitoring agents (RMA and Sniffer) on the main container given in parameter and launch them.
	 * RMA agent is used to debug and monitor the platform, and Sniffer agent is used to monitor communications.
	 * @param mc The main container's reference
	 */
	private static void createMonitoringAgents(ContainerController mc) {

		Assert.assertNotNull(mc);
		System.out.println("Launching the RMA agent on the main container...");
		AgentController rma;

		try {
			rma = mc.createNewAgent("rma", "jade.tools.rma.rma", new Object[0]);
			rma.start();
		} catch (StaleProxyException e) {
			e.printStackTrace();
			System.out.println("Launching of RMA agent failed");
		}

		System.out.println("Launching the Sniffer agent on the main container...");
		AgentController snif = null;

		try {
			snif = mc.createNewAgent("sniffeur", "jade.tools.sniffer.Sniffer", new Object[0]);
			snif.start();

		} catch (StaleProxyException e) {
			e.printStackTrace();
			System.out.println("Launching of Sniffer agent failed");
		}
	}

	/**
	 * Create the agents and add them to the agentList. Agents are NOT started.
	 * @param containerList Name and container's reference
	 * @return the agentList
	 */
	private static List<AgentController> createAgents(HashMap<String, ContainerController> containerList) {
		System.out.println("Creating agents...");
		ContainerController c;
		String agentName;
		List<AgentController> agentList = new ArrayList<AgentController>();

		if (ConfigurationFile.COMPUTERisMAIN) {
			/*
			 * The main platform is on this computer, we deploy the GateKeeper
			 */
			c = containerList.get(ConfigurationFile.LOCAL_CONTAINER_NAME);
			Assert.assertNotNull("This container does not exist", c);
			agentName = ConfigurationFile.DEFAULT_GATEKEEPER_NAME;
			try {
				Object[] objtab = new Object[] { ConfigurationFile.ENVIRONMENT_TYPE, ConfigurationFile.GENERATOR_TYPE,
						ConfigurationFile.INSTANCE_TOPOLOGY, ConfigurationFile.INSTANCE_CONFIGURATION_ELEMENTS,
						ConfigurationFile.ACTIVE_DIAMOND, ConfigurationFile.ACTIVE_GOLD, ConfigurationFile.ACTIVE_WELL,
						ConfigurationFile.GENERATOR_PARAMETERS };
				AgentController ag = c.createNewAgent(agentName, GateKeeperAgent.class.getName(), objtab);

				agentList.add(ag);
				System.out.println(agentName + " launched");
			} catch (StaleProxyException e) {
				e.printStackTrace();
			}
		}

		AgentController ag;

		// Define your agents here
		ContainerController c2 = containerList.get(ConfigurationFile.LOCAL_CONTAINER2_NAME);
		Assert.assertNotNull("This container does not exist", c2);
		Object[] entityParameters = { "My parameters" };

		agentName = "Explorer_1";
		ag = createNewDedaleAgent(c2, agentName, ExploreCoopAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Explorer_2";
		ag = createNewDedaleAgent(c2, agentName, ExploreCoopAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Explorer_3";
		ag = createNewDedaleAgent(c2, agentName, ExploreCoopAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Explorer_4";
		ag = createNewDedaleAgent(c2, agentName, ExploreCoopAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Collector_gold_1";
		ag = createNewDedaleAgent(c2, agentName, CollectorAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Collector_gold_2";
		ag = createNewDedaleAgent(c2, agentName, CollectorAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Collector_diamonds_1";
		ag = createNewDedaleAgent(c2, agentName, CollectorAgent.class.getName(), entityParameters);
		agentList.add(ag);

		agentName = "Collector_diamonds_2";
		ag = createNewDedaleAgent(c2, agentName, CollectorAgent.class.getName(), entityParameters);
		agentList.add(ag);

		System.out.println("Agents created...");
		return agentList;
	}

	/**
	 * Start the agents
	 * @param agentList
	 */
	private static void startAgents(List<AgentController> agentList) {

		System.out.println("Starting agents...");

		for (final AgentController ac : agentList) {
			try {
				ac.start();
			} catch (StaleProxyException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Agents started...");
	}

	private static AgentController createNewDedaleAgent(ContainerController initialContainer, String agentName,
														String className, Object[] additionalParameters) {
		Object[] objtab = AbstractDedaleAgent.loadEntityCaracteristics(agentName,
				ConfigurationFile.INSTANCE_CONFIGURATION_ENTITIES);
		Object[] res2 = merge(objtab, additionalParameters);

		AgentController ag = null;
		try {
			ag = initialContainer.createNewAgent(agentName, className, res2);
		} catch (StaleProxyException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(ag);
		System.out.println(agentName + " launched");
		return ag;
	}

	private static Object[] merge(Object[] tab1, Object[] tab2) {
		Assert.assertNotNull(tab1);
		Object[] res;
		if (tab2 != null) {
			res = new Object[tab1.length + tab2.length];
			int i = tab1.length;
			for (i = 0; i < tab1.length; i++) {
				res[i] = tab1[i];
			}
			for (int ind = 0; ind < tab2.length; ind++) {
				res[i] = tab2[ind];
				i++;
			}
		} else {
			res = tab1;
		}
		return res;
	}
}







