package eu.su.mas.dedaleEtu.mas.agents.definitions;

import java.util.ArrayList;
import java.util.List;

import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import eu.su.mas.dedale.mas.agent.behaviours.platformManagment.*;

import eu.su.mas.dedaleEtu.mas.behaviours.RandomWalkBehaviour;
import eu.su.mas.dedaleEtu.mas.behaviours.SayHelloBehaviour;

import jade.core.behaviours.Behaviour;

public class MovingAgent extends AbstractDedaleAgent {

	private static final long serialVersionUID = -2991562876411096907L;

	protected void setup() {
		super.setup();

		// Get the parameters provided in the object[]
		final Object[] args = getArguments();
		System.out.println("Parameters provided to " + this.getLocalName() + ": " + args[2]);

		// These parameters can be used as needed for the agent's behaviors.

		List<Behaviour> behaviors = new ArrayList<Behaviour>();

		// Add custom behaviors to the agent
		behaviors.add(new RandomWalkBehaviour(this)); // Adds a custom behavior for random walking
		behaviors.add(new SayHelloBehaviour(this));   // Adds a custom behavior for saying hello

		// Start the agent's behaviors
		addBehaviour(new startMyBehaviours(this, behaviors));
	}

	protected void takeDown() {
		super.takeDown();
	}

	protected void beforeMove() {
		super.beforeMove();
	}

	protected void afterMove() {
		super.afterMove();
	}
}
