package eu.su.mas.dedaleEtu.mas.knowledge;

// Import necessary Java and GraphStream libraries
import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;
import org.graphstream.algorithm.Dijkstra;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.fx_viewer.FxViewer;
import org.graphstream.ui.view.Viewer;
import dataStructures.serializableGraph.*;
import dataStructures.tuple.Couple;
import javafx.application.Platform;

// Class representing the map knowledge of an agent in a multi-agent system
public class MapRepresentation implements Serializable {

	// Enumeration to represent different attributes a map node can have
	public enum MapAttribute {
		agent, open, closed
	}

	// Serialization ID for object serialization
	private static final long serialVersionUID = -1333959882640838272L;

	// Style settings for graph nodes
	private String defaultNodeStyle = "node {" + "fill-color: black;" + " size-mode:fit;text-alignment:under; text-size:14;text-color:white;text-background-mode:rounded-box;text-background-color:black;}";
	private String nodeStyle_open = "node.agent {" + "fill-color: forestgreen;" + "}";
	private String nodeStyle_agent = "node.open {" + "fill-color: blue;" + "}";
	private String nodeStyle = defaultNodeStyle + nodeStyle_agent + nodeStyle_open;

	// GraphStream graph and viewer for graphical representation
	private Graph g;
	private Viewer viewer;
	private Integer nbEdges; // Number of edges in the graph
	private SerializableSimpleGraph<String, MapAttribute> sg; // Serializable version of the graph for storage or communication

	// Data structures for keeping track of node versions, planned paths, and reserved nodes
	private Map<String, Integer> nodeVersions = new HashMap<>();
	private Set<String> plannedPaths = new HashSet<>();
	private Map<String, List<String>> reservedNodes = new HashMap<>();

	// Constructor initializes the GraphStream settings and opens the GUI
	public MapRepresentation() {
		System.setProperty("org.graphstream.ui", "javafx");
		this.g = new SingleGraph("My world vision");
		this.g.setAttribute("ui.stylesheet", nodeStyle);

		Platform.runLater(() -> {
			openGui();
		});

		this.nbEdges = 0;
	}

	// Method to add a node to the graph with a specific attribute
	public synchronized void addNode(String id, MapAttribute mapAttribute) {
		Node n;
		if (this.g.getNode(id) == null) {
			n = this.g.addNode(id);
		} else {
			n = this.g.getNode(id);
		}
		n.clearAttributes();
		n.setAttribute("ui.class", mapAttribute.toString());
		n.setAttribute("ui.label", id);
	}

	// Method to add a new node to the graph if it does not already exist
	public synchronized boolean addNewNode(String id) {
		if (this.g.getNode(id) == null) {
			addNode(id, MapAttribute.open);
			return true;
		}
		return false;
	}

	// Method to add an edge between two nodes
	public synchronized void addEdge(String idNode1, String idNode2) {
		this.nbEdges++;
		try {
			this.g.addEdge(this.nbEdges.toString(), idNode1, idNode2);
		} catch (IdAlreadyInUseException e1) {
			System.err.println("ID existing");
			System.exit(1);
		} catch (EdgeRejectedException e2) {
			this.nbEdges--;
		} catch (ElementNotFoundException e3) {
			// Exception ignored, happens when elements are not found in the graph
		}
	}

	// Method to find the shortest path between two nodes using Dijkstra's algorithm
	public synchronized List<String> getShortestPath(String idFrom, String idTo) {
		List<String> shortestPath = new ArrayList<String>();

		Dijkstra dijkstra = new Dijkstra();
		dijkstra.init(g);
		dijkstra.setSource(g.getNode(idFrom));
		dijkstra.compute();
		List<Node> path = dijkstra.getPath(g.getNode(idTo)).getNodePath();
		Iterator<Node> iter = path.iterator();
		while (iter.hasNext()) {
			shortestPath.add(iter.next().getId());
		}
		dijkstra.clear();
		if (shortestPath.isEmpty()) {
			return null;
		} else {
			shortestPath.remove(0);
		}
		return shortestPath;
	}

	// Method to find the shortest path to the closest 'open' node from a given position
	public List<String> getShortestPathToClosestOpenNode(String myPosition) {
		List<String> openNodes = getOpenNodes();

		List<Couple<String, Integer>> lc = openNodes.stream()
				.map(on -> (getShortestPath(myPosition, on) != null) ? new Couple<String, Integer>(on,
						getShortestPath(myPosition, on).size())
						: new Couple<String, Integer>(on, Integer.MAX_VALUE))
				.collect(Collectors.toList());

		Optional<Couple<String, Integer>> closest = lc.stream().min(Comparator.comparing(Couple::getRight));

		return getShortestPath(myPosition, closest.get().getLeft());
	}

	// Method to retrieve a list of all 'open' nodes in the graph
	public List<String> getOpenNodes() {
		return this.g.nodes().filter(x -> x.getAttribute("ui.class") == MapAttribute.open.toString()).map(Node::getId)
				.collect(Collectors.toList());
	}

	// Method to prepare for agent migration by serializing the graph and closing the GUI
	public void prepareMigration() {
		serializeGraphTopology();

		closeGui();

		this.g = null;
	}

	// Helper method to serialize the graph topology into a simpler, serializable form
	private void serializeGraphTopology() {
		this.sg = new SerializableSimpleGraph<String, MapAttribute>();
		Iterator<Node> iter = this.g.iterator();
		while (iter.hasNext()) {
			Node n = iter.next();
			sg.addNode(n.getId(), MapAttribute.valueOf((String) n.getAttribute("ui.class")));
		}
		Iterator<Edge> iterE = this.g.edges().iterator();
		while (iterE.hasNext()) {
			Edge e = iterE.next();
			Node sn = e.getSourceNode();
			Node tn = e.getTargetNode();
			sg.addEdge(e.getId(), sn.getId(), tn.getId());
		}
	}

	// Method to retrieve the serializable version of the graph
	public synchronized SerializableSimpleGraph<String, MapAttribute> getSerializableGraph() {
		serializeGraphTopology();
		return this.sg;
	}

	// Method to load saved graph data into the current graph representation
	public synchronized void loadSavedData() {
		this.g = new SingleGraph("My world vision");
		this.g.setAttribute("ui.stylesheet", nodeStyle);

		openGui();

		Integer nbEd = 0;
		for (SerializableNode<String, MapAttribute> n : this.sg.getAllNodes()) {
			this.g.addNode(n.getNodeId()).setAttribute("ui.class", n.getNodeContent().toString());
			for (String s : this.sg.getEdges(n.getNodeId())) {
				this.g.addEdge(nbEd.toString(), n.getNodeId(), s);
				nbEd++;
			}
		}
		System.out.println("Loading done");
	}

	// Helper method to close the graphical user interface
	private synchronized void closeGui() {
		if (this.viewer != null) {
			try {
				this.viewer.close();
			} catch (NullPointerException e) {
				System.err.println("Bug graphstream viewer.close() work-around - https://github.com/graphstream/gs-core/issues/150");
			}
			this.viewer = null;
		}
	}

	// Helper method to open the graphical user interface
	private synchronized void openGui() {
		this.viewer = new FxViewer(this.g, FxViewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
		viewer.enableAutoLayout();
		viewer.setCloseFramePolicy(FxViewer.CloseFramePolicy.CLOSE_VIEWER);
		viewer.addDefaultView(true);

		g.display();
	}

	// Method to merge the current map representation with another received map
	public void mergeMap(SerializableSimpleGraph<String, MapAttribute> sgreceived) {
		for (SerializableNode<String, MapAttribute> n : sgreceived.getAllNodes()) {
			boolean alreadyIn = false;
			Node newnode = null;
			try {
				newnode = this.g.addNode(n.getNodeId());
			} catch (IdAlreadyInUseException e) {
				alreadyIn = true;
			}
			if (!alreadyIn) {
				newnode.setAttribute("ui.label", newnode.getId());
				newnode.setAttribute("ui.class", n.getNodeContent().toString());
			} else {
				newnode = this.g.getNode(n.getNodeId());
				if (((String) newnode.getAttribute("ui.class")) == MapAttribute.closed.toString()
						|| n.getNodeContent().toString() == MapAttribute.closed.toString()) {
					newnode.setAttribute("ui.class", MapAttribute.closed.toString());
				}
			}
		}

		for (SerializableNode<String, MapAttribute> n : sgreceived.getAllNodes()) {
			for (String s : sgreceived.getEdges(n.getNodeId())) {
				addEdge(n.getNodeId(), s);
			}
		}
	}

	// Method to reserve a node for an agent, ensuring exclusive access
	public synchronized boolean reserveNode(String nodeId, String agentId) {
		List<String> reservations = reservedNodes.getOrDefault(nodeId, new ArrayList<>());
		if (reservations.isEmpty()) {
			reservations.add(agentId);
			reservedNodes.put(nodeId, reservations);
			return true;
		}
		return false;
	}

	// Method to release a previously reserved node
	public synchronized void releaseNode(String nodeId, String agentId) {
		List<String> reservations = reservedNodes.getOrDefault(nodeId, new ArrayList<>());
		reservations.remove(agentId);
		if (reservations.isEmpty()) {
			reservedNodes.remove(nodeId);
		} else {
			reservedNodes.put(nodeId, reservations);
		}
	}

	// Method to check if a node is currently reserved
	public synchronized boolean isNodeReserved(String nodeId) {
		return reservedNodes.containsKey(nodeId) && !reservedNodes.get(nodeId).isEmpty();
	}

	// Method to check if there are any 'open' nodes in the graph
	public boolean hasOpenNode() {
		return this.g.nodes().filter(n -> n.getAttribute("ui.class") == MapAttribute.open.toString()).findAny()
				.isPresent();
	}
}


