package eu.su.mas.dedaleEtu.mas.behaviours;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import dataStructures.serializableGraph.SerializableSimpleGraph;

import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import eu.su.mas.dedaleEtu.mas.knowledge.MapRepresentation;
import eu.su.mas.dedaleEtu.mas.knowledge.MapRepresentation.MapAttribute;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

/**
 * A behavior for periodically sharing the agent's map with specified receivers.
 * It sends the entire graph to illustrate how to share knowledge.
 */
public class ShareMapBehaviour extends TickerBehaviour {

	private MapRepresentation mapRepresentation;
	private List<String> receiverAgentNames;
	private static final Logger logger = Logger.getLogger(ShareMapBehaviour.class.getName());

	private static final int MAX_RETRIES = 3; // Maximum number of message sending retries
	private static final long TIMEOUT = 2000; // Timeout for message sending in milliseconds

	/**
	 * Constructs a ShareMapBehaviour.
	 *
	 * @param a                  the agent
	 * @param period             the periodicity of the behavior (in ms)
	 * @param mapRepresentation  the map to share
	 * @param receiverAgentNames the list of agent names to send the map to
	 */
	public ShareMapBehaviour(Agent a, long period, MapRepresentation mapRepresentation, List<String> receiverAgentNames) {
		super(a, period);
		this.mapRepresentation = mapRepresentation;
		this.receiverAgentNames = receiverAgentNames;
	}

	@Override
	protected void onTick() {
		// Debugging statement to log receiverAgentNames
		logger.log(Level.INFO, "Receiver Agent Names: {0}", receiverAgentNames);
		shareMap();
	}

	private void shareMap() {
		ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
		msg.setProtocol("SHARE-TOPO");
		msg.setSender(this.myAgent.getAID());

		for (String agentName : receiverAgentNames) {
			msg.addReceiver(new AID(agentName, AID.ISLOCALNAME));
		}

		SerializableSimpleGraph<String, MapAttribute> serializableGraph = mapRepresentation.getSerializableGraph();

		int retries = 0;
		boolean sentSuccessfully = false;

		while (retries < MAX_RETRIES && !sentSuccessfully) {
			try {
				msg.setContentObject(serializableGraph);
				((AbstractDedaleAgent) this.myAgent).sendMessage(msg);

				logger.log(Level.INFO, "Sending map to {0} agents: {1}", new Object[]{receiverAgentNames.size(), receiverAgentNames});
				logger.log(Level.INFO, "Map shared with {0} agents.", receiverAgentNames.size());
				sentSuccessfully = true;
			} catch (IOException e) {
				logger.log(Level.SEVERE, "Error while sharing map: {0}", e.getMessage());
				retries++;
				if (retries < MAX_RETRIES) {
					logger.log(Level.WARNING, "Retrying message sending ({0}/{1}) in {2} ms...",
							new Object[]{retries, MAX_RETRIES, TIMEOUT});
					try {
						Thread.sleep(TIMEOUT);
					} catch (InterruptedException ex) {
						logger.log(Level.SEVERE, "Error while sleeping: {0}", ex.getMessage());
					}
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Error sending message: {0}", e.getMessage());
			}
		}
	}
}


