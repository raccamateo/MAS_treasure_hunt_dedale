package eu.su.mas.dedaleEtu.mas.behaviours;

import eu.su.mas.dedale.env.Location;
import eu.su.mas.dedale.mas.AbstractDedaleAgent;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

public class SayHelloBehaviour extends TickerBehaviour {

	private static final long serialVersionUID = -2058134622078521998L;

	// Constructor for the SayHelloBehavior, which takes an agent as a parameter
	public SayHelloBehaviour(final Agent myagent) {
		super(myagent, 3000); // Executes the behavior every 3000 milliseconds (3 seconds)
	}

	@Override
	public void onTick() {
		// Get the current position of the agent
		Location myPosition = ((AbstractDedaleAgent) this.myAgent).getCurrentPosition();

		// Create an ACL message to send
		ACLMessage msg = new ACLMessage(ACLMessage.INFORM);

		// Set the sender of the message to the agent's AID
		msg.setSender(this.myAgent.getAID());

		// Set the protocol for the message (in this case, a "UselessProtocol")
		msg.setProtocol("UselessProtocol");

		if (myPosition != null && !myPosition.getLocationId().equals("")) {
			// If the agent has a valid position, create a message with its location
			msg.setContent("Hello World, I'm at " + myPosition);

			// Add receivers to the message (in this case, a list of agent AIDs including all the defined at agents.json)
			msg.addReceiver(new AID("Explorer_1", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Explorer_2", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Explorer_3", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Explorer_4", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Collector_gold_1", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Collector_gold_2", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Collector_diamonds_1", AID.ISLOCALNAME));
			msg.addReceiver(new AID("Collector_diamonds_2", AID.ISLOCALNAME));

			// Send the message using the agent's environment to determine reachability
			((AbstractDedaleAgent) this.myAgent).sendMessage(msg);
		}
	}
}
